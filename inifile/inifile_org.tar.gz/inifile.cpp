/**
 * @file
 * @brief initialization file read and write API implementation
 * @author Deng Yangjun
 * @date 2007-1-9
 * @version 0.2
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include <android/asset_manager.h>
#include "inifile.h"


#define MAX_FILE_SIZE 1024*16
#define LEFT_BRACE '['
#define RIGHT_BRACE ']'

static bool load_ini_file(const char *file, char *buf,int *file_size)
{
	FILE *in = NULL;
	int i=0;
	*file_size =0;

	assert(file !=NULL);
	assert(buf !=NULL);

	in = fopen(file,"r");
	if( NULL == in) {
        return false;
	}

	buf[i]=fgetc(in);
	
	//load initialization file
	while( buf[i]!= (char)EOF) {
		i++;
		assert( i < MAX_FILE_SIZE ); //file too big, you can redefine MAX_FILE_SIZE to fit the big file 
		buf[i]=fgetc(in);
	}
	
	buf[i]='\0';
	*file_size = i;

	fclose(in);
    return true;
}

static bool newline(char c)
{
    return ('\n' == c ||  '\r' == c )? true : false;
}
static bool end_of_string(char c)
{
    return '\0'==c? true : false;
}
static bool left_barce(char c)
{
    return LEFT_BRACE == c? true : false;
}
static bool isright_brace(char c )
{
    return RIGHT_BRACE == c? true : false;
}
static bool parse_file(const char *section, const char *key, const char *buf,int *sec_s,int *sec_e,
					  int *key_s,int *key_e, int *value_s, int *value_e)
{
	const char *p = buf;
	int i=0;

	assert(buf!=NULL);
	assert(section != NULL && strlen(section));
	assert(key != NULL && strlen(key));

	*sec_e = *sec_s = *key_e = *key_s = *value_s = *value_e = -1;

	while( !end_of_string(p[i]) ) {
		//find the section
		if( ( 0==i ||  newline(p[i-1]) ) && left_barce(p[i]) )
		{
			int section_start=i+1;

			//find the ']'
			do {
				i++;
			} while( !isright_brace(p[i]) && !end_of_string(p[i]));

			if( 0 == strncmp(p+section_start,section, i-section_start)) {
				int newline_start=0;

				i++;

				//Skip over space char after ']'
				while(isspace(p[i])) {
					i++;
				}

				//find the section
				*sec_s = section_start;
				*sec_e = i;

				while( ! (newline(p[i-1]) && left_barce(p[i])) 
				&& !end_of_string(p[i]) ) {
					int j=0;
					//get a new line
					newline_start = i;

					while( !newline(p[i]) &&  !end_of_string(p[i]) ) {
						i++;
					}
					
					//now i  is equal to end of the line
					j = newline_start;

					if(';' != p[j]) //skip over comment
					{
						while(j < i && p[j]!='=') {
							j++;
							if('=' == p[j]) {
								if(strncmp(key,p+newline_start,j-newline_start)==0)
								{
									//find the key ok
									*key_s = newline_start;
									*key_e = j-1;

									*value_s = j+1;
									*value_e = i;

                                    return true;
								}
							}
						}
					}

					i++;
				}
			}
		}
		else
		{
			i++;
		}
	}
    return false;
}

/**
*@brief read string in initialization file\n
* retrieves a string from the specified section in an initialization file
*@param section [in] name of the section containing the key name
*@param key [in] name of the key pairs to value 
*@param value [in] pointer to the buffer that receives the retrieved string
*@param size [in] size of result's buffer 
*@param default_value [in] default value of result
*@param file [in] path of the initialization file
*@return true : read success; \n false : read fail
*/
bool GetProfileString( const char *section, const char *key,char *value,
		 int size, const char *default_value, const char *file)
{
	char buf[MAX_FILE_SIZE]={0};
	int file_size;
	int sec_s,sec_e,key_s,key_e, value_s, value_e;

	//check parameters
	assert(section != NULL && strlen(section));
	assert(key != NULL && strlen(key));
	assert(value != NULL);
	assert(size > 0);
	assert(file !=NULL &&strlen(key));

	if(!load_ini_file(file,buf,&file_size))
	{
		if(default_value!=NULL)
		{
			strncpy(value,default_value, size);
		}
        return false;
	}

	if(!parse_file(section,key,buf,&sec_s,&sec_e,&key_s,&key_e,&value_s,&value_e))
	{
		if(default_value!=NULL)
		{
			strncpy(value,default_value, size);
		}
        
        return false; //not find the key
	}
	else
	{
		int cpcount = value_e -value_s;

		if( size-1 < cpcount)
		{
			cpcount =  size-1;
		}
	
		memset(value, 0, size);
		memcpy(value,buf+value_s, cpcount );
		value[cpcount] = '\0';

        return true;
	}
}

/**
*@brief read int value in initialization file\n
* retrieves int value from the specified section in an initialization file
*@param section [in] name of the section containing the key name
*@param key [in] name of the key pairs to value 
*@param default_value [in] default value of result
*@param file [in] path of the initialization file
*@return profile int value,if read fail, return default value
*/
int GetProfileInt( const char *section, const char *key,int default_value,
				const char *file)
{
	char value[32] = {0};
    if(!GetProfileString(section,key,value, sizeof(value),NULL,file))
	{
		return default_value;
	}
	else
	{
		return atoi(value);
	}
}

/**
 * @brief write a profile string to a ini file
 * @param section [in] name of the section,can't be NULL and empty string
 * @param key [in] name of the key pairs to value, can't be NULL and empty string
 * @param value [in] profile string value
 * @param file [in] path of ini file
 * @return 1 : success\n 0 : failure
 */
bool WriteProfileString(const char *section, const char *key,
					const char *value, const char *file)
{
	char buf[MAX_FILE_SIZE]={0};
	char w_buf[MAX_FILE_SIZE]={0};
	int sec_s,sec_e,key_s,key_e, value_s, value_e;
	int value_len = (int)strlen(value);
	int file_size;
	FILE *out;

	//check parameters
	assert(section != NULL && strlen(section));
	assert(key != NULL && strlen(key));
	assert(value != NULL);
	assert(file !=NULL &&strlen(key));

	if(!load_ini_file(file,buf,&file_size))
	{
		sec_s = -1;
	}
	else
	{
		parse_file(section,key,buf,&sec_s,&sec_e,&key_s,&key_e,&value_s,&value_e);
	}

	if( -1 == sec_s)
	{
		if(0==file_size)
		{
			sprintf(w_buf+file_size,"[%s]\n%s=%s\n",section,key,value);
		}
		else
		{
			//not find the section, then add the new section at end of the file
			memcpy(w_buf,buf,file_size);
			sprintf(w_buf+file_size,"\n[%s]\n%s=%s\n",section,key,value);
		}
	}
	else if(-1 == key_s)
	{
		//not find the key, then add the new key=value at end of the section
		memcpy(w_buf,buf,sec_e);
		sprintf(w_buf+sec_e,"%s=%s\n",key,value);
		sprintf(w_buf+sec_e+strlen(key)+strlen(value)+2,buf+sec_e, file_size - sec_e);
	}
	else
	{
		//update value with new value
		memcpy(w_buf,buf,value_s);
		memcpy(w_buf+value_s,value, value_len);
		memcpy(w_buf+value_s+value_len, buf+value_e, file_size - value_e);
	}
	
	out = fopen(file,"w");
	if(NULL == out)
	{
        return false;
	}
	
	if(-1 == fputs(w_buf,out) )
	{
		fclose(out);
        return false;
	}

	fclose(out);
    return true;
}

bool WriteProfileInt( const char * lpSecName,const char * lpKeyName, int value, const char * lpFileName)
{
    char szString[32];
    sprintf(szString, "%d", value);
    return WriteProfileString(lpSecName, lpKeyName, szString, lpFileName);
}
bool WriteProfileFloat(  const char *lpSecName, const char * lpKeyName, float value,  const char*  lpFileName)
{
    char szString[32];
    sprintf(szString, "%10.5f", value);

    return WriteProfileString(lpSecName, lpKeyName, szString, lpFileName);
}
bool WriteProfileDouble(  const char *lpSecName, const char * lpKeyName, double value,  const char*  lpFileName)
{
    char szString[32];
    sprintf(szString, "%12.7f", value);

    return WriteProfileString(lpSecName, lpKeyName, szString, lpFileName);
}
float GetProfileFloat(const char *lpSecName, const char *lpKeyName, float fDefault,  const char *lpFileName)
{
    char value[64];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return fDefault;
    return (float) atof(value);
}
double GetProfileDouble(const char *lpSecName, const char *lpKeyName, double dbDefault,  const char *lpFileName)
{
    char value[64];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return dbDefault;
    return atof(value);
}

bool WriteProfilePointFloat(const char *lpSecName, const char *lpKeyName,  nfFloat2D *pPoint, const char *lpFileName)
{
    char szString[64];
    sprintf(szString, "%10.5f, %10.5f", pPoint->x, pPoint->y);
    return WriteProfileString(lpSecName, lpKeyName, szString, lpFileName);
}
bool GetProfilePointFloat(const char * lpSecName, const char * lpKeyName,  nfFloat2D* pPoint, const char * lpFileName)
{
    char value[256];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return false;

    char* p1 = strtok(value, ",");
    if(!p1) return -1;
    pPoint->x = (float) atof(p1);
    p1 = strtok(NULL,",;");
    if(!p1) return false;
    pPoint->y = (float) atof(p1);
    return true;
}

bool WriteProfileArrayFloat(const char * lpSecName, const char * lpKeyName,  float* pValue, int nElements, const char * lpFileName)
{
    char szString[64];
    char szArray[512]={0};
    for (int i=0; i< nElements; i++) {
        sprintf(szString, "%10.5f,", pValue[i]);
        strcat(szArray, szString);
    }
    return WriteProfileString(lpSecName, lpKeyName, szArray, lpFileName);
}
bool GetProfileArrayFloat(const char * lpSecName, const char * lpKeyName,   float* pValue, int nElements,  const char * lpFileName)
{
    char value[512];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return false;
    char* p1 = strtok(value, ",");
    bool bResult = true;
    for(int i=0; i<nElements; i++) {
        if (p1 == NULL) {
            bResult = false;
            break;
        }
        pValue[i] = atof(p1);
        p1 = strtok(NULL, ",");
    }
    return bResult;
}
bool WriteProfileArrayInt(const char * lpSecName, const char * lpKeyName,  int* pValue, int nElements, const char * lpFileName)
{
    char szString[64];
    char szArray[512]={0};
    for (int i=0; i< nElements; i++) {
        sprintf(szString, " %d,", pValue[i]);
        strcat(szArray, szString);
    }
    return WriteProfileString(lpSecName, lpKeyName, szArray, lpFileName);
}

bool GetProfileArrayInt(const char * lpSecName, const char * lpKeyName,   int* pValue, int nElements,  const char * lpFileName)
{
    char value[512];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return false;
    char* p1 = strtok(value, ",");
    bool bResult = true;
    for(int i=0; i<nElements; i++) {
        if (p1 == NULL) {
            bResult = false;
            break;
        }
        pValue[i] = atoi(p1);
        p1 = strtok(NULL, ",");
    }
    return bResult;
}


bool	WriteProfileRectFloat(const char * lpSecName, const char * lpKeyName,  nfRectF* pRect, const char * lpFileName)
{
    char szString[512];
    sprintf(szString, "%10.5f, %10.5f, %10.5f, %10.5f", pRect->l, pRect->t, pRect->r, pRect->b);
    return WriteProfileString(lpSecName, lpKeyName, szString, lpFileName);

}
bool GetProfileRectFloat(const char * lpSecName, const char * lpKeyName,  nfRectF* pRect, const char * lpFileName)
{
    char value[256];
    if( false == GetProfileString(lpSecName, lpKeyName, value, sizeof(value), "0", lpFileName))
        return false;

    char* p1 = strtok(value, ",");
    if(!p1) return false;
    pRect->l = atof(p1);
    p1 = strtok(NULL,",");
    if(!p1) return false;
    pRect->t = atof(p1);
    p1 = strtok(NULL,",");
    if(!p1) return false;
    pRect->r = atof(p1);
    p1 = strtok(NULL,",");
    if(!p1) return false;
    pRect->b = atof(p1);

    return true;
}
